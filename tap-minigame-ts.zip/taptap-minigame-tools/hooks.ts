/**
 * Tap小游戏构建钩子
 * 用途：在构建完成后自动调用TypeScript转换器
 */

import * as fs from 'fs';
import * as path from 'path';
import { convertWechatToTap } from './converter-ts';
import { spawn } from 'child_process';

/**
 * 检查Node.js版本是否兼容
 */
function checkNodeVersionCompatibility(): { compatible: boolean; version: string; message: string } {
    const nodeVersion = process.version; // e.g., "v14.17.0"
    const majorVersion = parseInt(nodeVersion.split('.')[0].substring(1));

    if (majorVersion < 12) {
        return {
            compatible: false,
            version: nodeVersion,
            message: `Node.js版本过低（${nodeVersion}），需要12.0或更高版本。\n\n请升级Cocos Creator到3.8.0或更高版本。`
        };
    }

    return {
        compatible: true,
        version: nodeVersion,
        message: `Node.js版本兼容（${nodeVersion}）`
    };
}

/**
 * 检查Python环境是否可用
 */
async function checkPythonAvailable(): Promise<{ available: boolean; version: string }> {
    return new Promise((resolve) => {
        try {
            const python = process.platform === 'win32' ? 'python' : 'python3';
            const child = spawn(python, ['--version'], { stdio: 'pipe' });

            let output = '';
            let resolved = false;

            child.stdout.on('data', (data) => { output += data.toString(); });
            child.stderr.on('data', (data) => { output += data.toString(); });

            child.on('close', (code) => {
                if (resolved) return;
                resolved = true;
                if (code === 0 && output.includes('Python')) {
                    resolve({ available: true, version: output.trim() });
                } else {
                    resolve({ available: false, version: '' });
                }
            });

            child.on('error', (error) => {
                if (resolved) return;
                resolved = true;
                console.log('[Tap小游戏] Python检测出错:', error.message);
                resolve({ available: false, version: '' });
            });

            // 超时处理
            setTimeout(() => {
                if (resolved) return;
                resolved = true;
                try {
                    child.kill();
                } catch (e) {
                    // 忽略kill错误
                }
                resolve({ available: false, version: '' });
            }, 3000);
        } catch (error: any) {
            // spawn本身可能失败
            console.log('[Tap小游戏] Python检测失败:', error.message);
            resolve({ available: false, version: '' });
        }
    });
}

/**
 * 检查转换器依赖是否完整
 */
function checkConverterDependencies(): { ok: boolean; message: string } {
    // 修正路径：__dirname在编译后指向dist/，需要回到上层
    const converterDir = path.join(__dirname, '..', 'converter');
    const nodeModulesPath = path.join(converterDir, 'node_modules');
    const packageJsonPath = path.join(converterDir, 'package.json');
    const babelPath = path.join(nodeModulesPath, '.bin', 'babel');

    console.log('[Tap小游戏] 检查转换器依赖...');
    console.log('[Tap小游戏] converter目录:', converterDir);

    // 检查package.json
    if (!fs.existsSync(packageJsonPath)) {
        console.log('[Tap小游戏] ✗ package.json不存在');
        return {
            ok: false,
            message: '插件安装不完整，缺少converter/package.json。\n请重新安装插件。'
        };
    }
    console.log('[Tap小游戏] ✓ package.json存在');

    // 检查node_modules
    if (!fs.existsSync(nodeModulesPath)) {
        console.log('[Tap小游戏] ✗ node_modules不存在');
        return {
            ok: false,
            message: '转换器依赖未安装。\n\n首次使用会自动安装，请稍候1-2分钟。\n如果安装失败，请检查网络连接。'
        };
    }
    console.log('[Tap小游戏] ✓ node_modules存在');

    // 检查babel命令（Windows检查.cmd，其他检查普通文件）
    const isWindows = process.platform === 'win32';
    const babelCmdPath = isWindows ? babelPath + '.cmd' : babelPath;

    if (!fs.existsSync(babelCmdPath)) {
        console.log('[Tap小游戏] ✗ babel命令不存在:', babelCmdPath);
        return {
            ok: false,
            message: 'Babel转换工具未安装。\n\n首次使用会自动安装，请稍候1-2分钟。'
        };
    }
    console.log('[Tap小游戏] ✓ babel命令存在');

    return {
        ok: true,
        message: '转换器依赖完整'
    };
}

/**
 * 构建前环境检查（完整版）
 */
async function checkEnvironment(): Promise<{ ok: boolean; message: string; hasPythonFallback: boolean }> {
    console.log('[Tap小游戏] ========================================');
    console.log('[Tap小游戏] 🔍 开始环境检查...');
    console.log('[Tap小游戏] ========================================');

    // 1. 检查Node.js版本
    const nodeCheck = checkNodeVersionCompatibility();
    console.log('[Tap小游戏] Node.js版本:', nodeCheck.version);

    // 2. 检查转换器依赖
    const depsCheck = checkConverterDependencies();

    // 3. 检查Python保底方案
    console.log('[Tap小游戏] 检查Python保底方案...');
    const pythonCheck = await checkPythonAvailable();

    if (pythonCheck.available) {
        console.log('[Tap小游戏] ✓ 检测到Python环境:', pythonCheck.version);
    } else {
        console.log('[Tap小游戏] - 未检测到Python环境');
    }

    // 综合判断
    if (!nodeCheck.compatible) {
        console.log('[Tap小游戏] ⚠️  Node.js版本较低（建议12.0+）');

        if (pythonCheck.available) {
            console.log('[Tap小游戏] 如果TypeScript转换失败，将自动使用Python保底方案');
            return {
                ok: true,
                message: `Node.js版本较低，但检测到${pythonCheck.version}作为保底方案。`,
                hasPythonFallback: true
            };
        } else {
            return {
                ok: true, // 仍然让它继续，转换时可能成功
                message: nodeCheck.message,
                hasPythonFallback: false
            };
        }
    }

    if (!depsCheck.ok) {
        console.log('[Tap小游戏] ⚠️  转换器依赖不完整');

        if (pythonCheck.available) {
            console.log('[Tap小游戏] 检测到Python环境，可作为保底方案');
            return {
                ok: true,
                message: `转换器依赖不完整，但检测到${pythonCheck.version}作为保底方案。\n\n${depsCheck.message}`,
                hasPythonFallback: true
            };
        } else {
            return {
                ok: true, // 让它继续，首次使用会自动安装依赖
                message: depsCheck.message,
                hasPythonFallback: false
            };
        }
    }

    console.log('[Tap小游戏] ✓ Node.js版本兼容');
    console.log('[Tap小游戏] ✓ 转换器依赖完整');
    console.log('[Tap小游戏] ========================================');
    console.log('[Tap小游戏] ✅ 环境检查通过');
    console.log('[Tap小游戏] ========================================');

    return {
        ok: true,
        message: '环境检查通过',
        hasPythonFallback: pythonCheck.available
    };
}

export async function onBeforeBuild(options: any) {
    // 注意：环境检查已完全屏蔽
    // 原因：所有依赖已集成到插件包中（14MB），无需检查系统环境
    // 插件包包含：
    // 1. 主插件依赖：fs-extra、archiver
    // 2. 转换器依赖：Babel工具链
    // 3. Python保底脚本：wx_converter.py
    //
    // 如果有任何问题，会在转换时准确报告

    console.log('[Tap小游戏] 准备构建微信小游戏');
}

// Python相关代码已完全移除
// 只保留强制使用Python的选项（用户主动勾选时才使用）

export async function onAfterBuild(options: any, result: any) {
    console.log('[Tap小游戏] 微信小游戏构建完成！');

    // 检查是否启用了Tap转换
    const tapOptions = options.packages?.['taptap-minigame-tools'];
    if (!tapOptions || !tapOptions.enableTapConvert) {
        console.log('[Tap小游戏] 未启用Tap转换，跳过');
        console.log('[Tap小游戏] 调试信息 - packages:', Object.keys(options.packages || {}));
        return;
    }

    console.log('[Tap小游戏] 开始转换为Tap小游戏...');

    try {
        // 获取微信小游戏构建路径
        const wechatBuildPath = result.dest;
        console.log('[Tap小游戏] 微信小游戏路径:', wechatBuildPath);

        // 创建TapBuild目录（与微信小游戏目录同级）
        const buildDir = path.dirname(wechatBuildPath);
        const tapBuildPath = path.join(buildDir, 'TapBuild');

        // 如果TapBuild目录存在，先删除
        if (fs.existsSync(tapBuildPath)) {
            console.log('[Tap小游戏] 删除旧的TapBuild目录...');
            fs.rmSync(tapBuildPath, { recursive: true, force: true });
        }

        // 创建新的TapBuild目录
        fs.mkdirSync(tapBuildPath, { recursive: true });
        console.log('[Tap小游戏] 创建TapBuild目录:', tapBuildPath);

        // 注意："强制使用Python脚本"选项已移除
        // 只使用TypeScript转换器
        console.log('[Tap小游戏] ========================================');
        console.log('[Tap小游戏] 📦 使用TypeScript转换器');
        console.log('[Tap小游戏] ========================================');

        await convertWechatToTap({
            source: wechatBuildPath,
            target: tapBuildPath,
            useSubpackage: false
        });

        console.log('[Tap小游戏] ✅ TypeScript转换器执行成功');

        // 验证zip文件是否生成
        console.log('[Tap小游戏] ========================================');
        console.log('[Tap小游戏] ✅ 转换完成！');
        console.log('[Tap小游戏] ========================================');

        const gameZipPath = path.join(tapBuildPath, 'game.zip');
        if (fs.existsSync(gameZipPath)) {
            const stats = fs.statSync(gameZipPath);
            const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
            console.log('[Tap小游戏] game.zip已生成:', gameZipPath);
            console.log('[Tap小游戏] 文件大小:', sizeMB, 'MB');
        } else {
            console.log('[Tap小游戏] ⚠️  game.zip未生成');
        }

        // 检查是否需要删除微信小游戏包
        if (tapOptions.deleteWechatBuild) {
            console.log('[Tap小游戏] ========================================');
            console.log('[Tap小游戏] 🗑️  删除微信小游戏包...');
            console.log('[Tap小游戏] ========================================');

            try {
                if (fs.existsSync(wechatBuildPath)) {
                    console.log('[Tap小游戏] 删除目录:', wechatBuildPath);
                    fs.rmSync(wechatBuildPath, { recursive: true, force: true });
                    console.log('[Tap小游戏] ✅ 微信小游戏包已删除');
                } else {
                    console.log('[Tap小游戏] ⚠️  微信小游戏目录不存在，跳过删除');
                }
            } catch (deleteError: any) {
                console.log('[Tap小游戏] ⚠️  删除微信小游戏包失败:', deleteError.message);
                console.log('[Tap小游戏] 可以手动删除目录:', wechatBuildPath);
            }
        }

    } catch (error: any) {
        console.log('[Tap小游戏] ========================================');
        console.log('[Tap小游戏] ❌ 转换失败');
        console.log('[Tap小游戏] ========================================');
        console.log('[Tap小游戏] 错误详情:', error.message);

        // 弹出错误提示
        Editor.Dialog.error(
            '转换失败，请查看控制台日志获取详细信息。\n\n' + error.message,
            {
                title: 'Tap小游戏',
                buttons: ['确定']
            }
        );

        throw error;
    }
}
